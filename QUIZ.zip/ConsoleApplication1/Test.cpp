#include<iostream>
#include<fstream>
#include<string>
#include<conio.h>
#include <cstdlib>
using namespace std;

void main()
{
	system("color 1c");
	string name;//for inputing name
	char ans;
	int p_word, q_comp = 0;

	cout << "Enter your name : ";
	getline(cin,name);

	cout << "Enter Numeric Password :";
	cin >> p_word;
	system("cls");
	while (p_word != 1313)//if password wrong then this will continue until loop become true
	{
		cout << "\n\t\tWrong password";
		cout << "\n\nPlease Enter Password Again :";
		cin >> p_word;
	}
	if (p_word == 1313)
		system("CLS");

	cout << "\n\t\t\t\tWelcome to your Quiz " << name << endl;

	ifstream q_reader;
	ofstream a_writer; // Handle for the input file
	a_writer.open(name + "_answers", ios::app); // Opening the file
	// checking that file is successfully opened or not
	if (!a_writer)
	{
		cout << "Some Error Occured while opening answer file.\n" << endl;
		_getche();
	}
	else
	{
		a_writer.seekp(0, ios::end);//pointing to the end of file
		q_reader.open("A:\\CP After Mids\\Project MCQ\\Filing Data question answer\\qpaper.txt");
		if (!q_reader)
		{
			cout << "!!! Error !!!\n\nCan't open the Question Paper File..." << endl;
			_getche();
		}
		else
		{

			char d_p_line[150];//to hold data per line
			while (!q_reader.eof())
			{

				q_reader.getline(d_p_line, 150);//150 characters per line can be read
				string q_check(d_p_line);
				if (q_check == "%%%")
				{
					char confirm = 'n';
					while (confirm == 'n' || confirm == 'N')
					{
						cout << "\nSelect any option(a,b,c or d)\n";
						ans = _getche();
						while (ans != 'a'&& ans != 'b' && ans != 'c' && ans != 'd'&&ans != 'A'&& ans != 'B' && ans != 'C' && ans != 'D')
						{
							cout << "\n!!! Wrong Selection !!!\n Please Again Select any Option (a,b,c/d)\n";
							ans = _getche();
						}
						cout << "\nYou have selected option \"" << ans << "\" for question \"" << q_comp + 1 << "\".\n"
							<< "Press any key to proceed to next question and \"n/N\" to select again...\n";
						confirm = _getche();
					}
					//one question completes here
					//wait here you can take input here bcoz we stop it on %%%
					// Writing into the file
					q_comp++;



					a_writer << "\n" << q_comp << " - " << ans;//writing the selected option at the end of file

					system("cls");

					cout << "\n\t\t\t\tQuiz has been started  " << name << endl;
					cout << "\nYou have Completed " << q_comp << " question";
				}
				else
				{
					cout << q_check << endl;
				}
			}
			q_reader.close();
			a_writer.close();
		}
	}

	system("cls");
	cout << "\nCongratulations...."
		<< "\nYou have Completed all " << q_comp << " questions.\n";

	system("pause");

}