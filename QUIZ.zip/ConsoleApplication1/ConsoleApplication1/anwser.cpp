#include<iostream>
#include<fstream>
#include<string>
#include<conio.h>
#include <cstdlib>
using namespace std;

void main()
{
	system("color 1c");
	string org_f_name, check_f_name;
	ifstream reader;
	int t_q = 0;
	char c_ans[10];
	cout << "Enter Original File name in same Folder : ";
	getline (cin, org_f_name);
	reader.open(org_f_name);
	//reader.open("A:\\CP After Mids\\Project MCQ\\Filing Data question answer\\Orignal file.txt");
	while (!reader)
	{
		system("cls");
		cout << "Orignal file " << org_f_name << " is not found or cannot be opened.\n\n Please Enter Correct File name :";
		getline(cin, org_f_name);
		reader.open(org_f_name);
		//reader.open("A:\\CP After Mids\\Project MCQ\\Filing Data question answer");
	}

	while (!reader.eof())
	{
		reader.getline(c_ans, 10);
		t_q++;
	}
	cout << "Total No of Questions are :" << t_q - 1 << endl;
	char *answers = new char[t_q];
	answers[0] = '0';
	reader.close();
	reader.open(org_f_name);
	if (!reader)
	{
		cout << "\n!!!Error!!!\nFile named " << org_f_name << " is not found or cannot be opened.";
	}
	else{
		t_q = 0;
		while (!reader.eof())
		{
			reader.getline(c_ans, 10);
			if (t_q>0 && t_q<10)
				answers[t_q] = c_ans[4];//here storing orignal answers at pointer array
			else if (t_q>9)
				answers[t_q] = c_ans[5];
			t_q++;
		}
		answers[t_q] = '\0';
		reader.close();
		char more_check = 'y';
		while (more_check == 'y' || more_check == 'Y')
		{
			cout << "Enter Answer file name to be chcked in the same folder : ";
			getline(cin, check_f_name);
			reader.open(check_f_name);
			while (!reader)
			{
				system("cls");
				cout << "\nFile named " << check_f_name << " is not found or cannot be opened.\n\n Please Enter Correct File to be Checked name :";
				getline(cin, check_f_name);
				reader.open(check_f_name);
			}
			int corect_q = 0;
			ofstream r_writer; // Handle for the input file
			r_writer.open(check_f_name + "_result", ios::app); // Opening the file ios append the file to end
			// checking that file is successfully opened or not
			//cout<< corect_q;
			if (!r_writer)
			{
				cout << "Some Error Occured while generating result file.\n" << endl;
				_getch();
			}
			else
			{
				r_writer.seekp(0, ios::end);//pointing to the end of file
				t_q = 0;
				while (!reader.eof())
				{
					reader.getline(c_ans, 10);
					r_writer << c_ans;
					if (t_q>0 && t_q<10)
					{
						if (c_ans[4] == answers[t_q])
						{
							corect_q++;
							r_writer << "  correct";
						}
						else
							r_writer << "  wrong";
					}
					else if (t_q>9)
					{
						if (c_ans[5] == answers[t_q])
						{
							corect_q++;
							r_writer << "  correct";
						}
						else
							r_writer << "  wrong";
					}
					r_writer << "\n";
					t_q++;
				}
				r_writer << "----------------------\n Total Marks : " << corect_q;
				r_writer.close();
				cout << "Total Marks for the answer file " << check_f_name << " : " << corect_q << endl;
				cout << "Result file has been created with name as " << check_f_name << "_result.\n";
			}
			reader.close();

			cout << "\nPress y to check another file or any key to exit\n";
			more_check = _getche();
			cout << endl;
		}
	}
	system("pause");

}






/*#include<iostream>
using namespace std;
void main()

{
int a[10];
for (int i = 0; i < 10; i++)
cin >> a[i];
for (int j = 9; j >= 0; j--)
cout << a[j] << endl;

system("pause");

}

*/











/*#include<iostream>
#include<fstream>
#include<string>
#include<conio.h>
#include <cstdlib>
using namespace std;

void main()
{
string name, a;//for inputing name
char ans;
int p_word, q_comp,check = 0;

cout << "Enter your name : ";
getline(cin, name);

cout << "Enter Numeric Password :";
cin >> p_word;
system("cls");
while (p_word != 1313)//if password wrong then this will continue until loop become true
{
cout << "\n\t\tWrong password";
cout << "\n\nPlease Enter Password Again :";
cin >> p_word;
}
if (p_word == 1313)
system("CLS");

cout << "\n\t\t\t\tWelcome to your Quiz " << name << endl;
ifstream ta("A:\\CP After Mids\\Project MCQ\\Filing Data question answer\\qpaper.txt");
while (!ta.eof())
{
getline(ta, a);
if (ta == "%%%")
{
cout << a << endl;
}
}
ta.close();
char answer[10];
for (int i = 0, j = 1; i < 10; i++,j++)
{
cout << "\nEnter your answer for question " << j << " ";
cin >> answer[i];

}

if (answer[0] == 'd' || answer[0] == 'D')
check++;

if (answer[0] == 'd' || answer[0] == 'D')
check++;

if (answer[0] == 'd' || answer[0] == 'D')
check++;

if (answer[1] == 'a' || answer[1] == 'A')
check++;

if (answer[0] == 'b' || answer[2] == 'B')
check++;

if (answer[3] == 'a' || answer[3] == 'A')
check++;

if (answer[4] == 'd' || answer[0] == 'D')
check++;

if (answer[5] == 'b' || answer[0] == 'B')
check++;

if (answer[6] == 'a' || answer[6] == 'A')
check++;

if (answer[7] == 'a' || answer[0] == 'A')
check++;

if (answer[8] == 'b' || answer[0] == 'B')
check++;

if (answer[9] == 'c' || answer[9] == 'C')
check++;
system("pause");
}*/